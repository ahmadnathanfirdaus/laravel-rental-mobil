<button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addCar">Tambah Mobil</button>
<button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addBrand">Tambah Merk</button>
<?php if(count($cars) > 0): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Merk</th>
                <th>Tipe</th>
                <th>Tahun</th>
                <th>Harga</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($car->brand->name); ?></td>
                    <td><?php echo e($car->name); ?></td>
                    <td><?php echo e($car->year); ?></td>
                    <td>Rp<?php echo e(number_format($car->price, 2, ',', '.')); ?></td>
                    <td><span
                            class="badge <?php echo e($car->status == 'available' ? 'bg-success' : 'bg-danger'); ?>"><?php echo e($car->status); ?></span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-success" data-bs-toggle="modal"
                            data-bs-target="#car-<?php echo e($i); ?>">Edit</button>
                        <form action="<?php echo e(route('cars.destroy', ['car' => $car])); ?>" method="POST" class="d-inline">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-danger"
                                onclick="return confirm('Hapus?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php echo $__env->make('admin.edit-car-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="alert alert-danger">Tidak ada data</p>
<?php endif; ?>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/admin/data-cars.blade.php ENDPATH**/ ?>