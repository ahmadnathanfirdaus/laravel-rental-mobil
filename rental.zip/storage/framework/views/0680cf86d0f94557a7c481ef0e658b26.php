<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between">
    <h4>Welcome, <?php echo e(auth()->user()->name); ?>!</h4>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger">Logout</button>
    </form>
</div>

<ul class="nav nav-tabs mt-3">
    <li class="nav-item">
        <a class="nav-link active">Data Mobil</a>
    </li>
    <li class="nav-item">
        <a class="nav-link">Data Penyewa</a>
    </li>
    <li class="nav-item">
        <a class="nav-link">Data User</a>
    </li>
</ul>
<?php echo $__env->yieldContent('admin-content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/layouts/admin.blade.php ENDPATH**/ ?>