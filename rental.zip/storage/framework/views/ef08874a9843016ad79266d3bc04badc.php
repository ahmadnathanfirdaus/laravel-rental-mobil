<div class="modal fade" id="car-<?php echo e($i); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="car-<?php echo e($i); ?>Label"><?php echo e($car->brand->name . ' ' . $car->name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('cars.update', ['car' => $car])); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="brand">Merk</label>
                        <select name="brand" id="brand" class="form-control">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>"
                                    <?php echo e($car->brand_id == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="name">Tipe</label>
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo e($car->name); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="year">Tahun</label>
                        <input type="number" class="form-control" id="year" name="year"
                            value="<?php echo e($car->year); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="price">Harga</label>
                        <input type="number" class="form-control" id="price" name="price"
                            value="<?php echo e($car->price); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="available" <?php echo e($car->status == 'available' ? 'selected' : ''); ?>>Available
                            </option>
                            <option value="unavailable" <?php echo e($car->status == 'unavailable' ? 'selected' : ''); ?>>
                                Unavailable</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/admin/edit-car-modal.blade.php ENDPATH**/ ?>