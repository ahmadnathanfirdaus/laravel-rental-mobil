<?php if(session('success')): ?>
    <div class="alert alert-success mt-3">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger mt-3">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/layouts/alert.blade.php ENDPATH**/ ?>