<?php if(count($rents) > 0): ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Penyewa</th>
                    <th>Mobil</th>
                    <th>Tanggal Sewa</th>
                    <th>Tanggal Pengembalian</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo e($rent->user->name); ?></td>
                        <td><?php echo e($rent->car->brand->name . ' ' . $rent->car->name); ?></td>
                        <td><?php echo e($rent->rent_date); ?></td>
                        <td><?php echo e($rent->return_date); ?></td>
                        <td>Rp<?php echo e(number_format($rent->total_price, 2, ',', '.')); ?></td>
                        <td>
                            <?php if($rent->status == 'pending'): ?>
                                <form action="<?php echo e(route('rents.approve', ['rent' => $rent])); ?>" class="d-inline" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" onclick="return confirm('Approve?')"
                                        class="btn btn-sm btn-success w-100">Approve</button>
                                </form>
                                <form action="<?php echo e(route('rents.deny', ['rent' => $rent])); ?>" class="d-inline" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" onclick="return confirm('Deny?')"
                                        class="btn btn-sm btn-danger w-100">Deny</button>
                                </form>
                            <?php elseif($rent->status == 'approved'): ?>
                                <span class="badge bg-success"><?php echo e($rent->status); ?></span>
                            <?php else: ?>
                                <span class="badge bg-danger"><?php echo e($rent->status); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <p class="alert alert-danger">Tidak ada data</p>
<?php endif; ?>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/admin/data-rents.blade.php ENDPATH**/ ?>