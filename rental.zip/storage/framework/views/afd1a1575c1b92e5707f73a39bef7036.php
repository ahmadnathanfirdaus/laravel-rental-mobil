<div class="modal fade" id="car-<?php echo e($i); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="car-<?php echo e($i); ?>Label"><?php echo e($car->brand->name . ' ' . $car->name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('rents.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" id="user_id" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                    <input type="hidden" id="car_id" name="car_id" value="<?php echo e($car->id); ?>">
                    <input type="hidden" id="total_price" name="total_price" value="<?php echo e($car->price); ?>">
                    <div class="mb-3">
                        <label for="rent_date">Rent Date:</label>
                        <input type="date" class="form-control" id="rent_date" name="rent_date"
                            onchange="calculatePrice(<?php echo e($car->price); ?>)">
                    </div>
                    <div class="mb-3">
                        <label for="return_date">Return Date:</label>
                        <input type="date" class="form-control" id="return_date" name="return_date"
                            onchange="calculatePrice(<?php echo e($car->price); ?>)">
                    </div>
                    <p class="mb-3">
                        <strong>Total hari:</strong> <span id="total_days">0</span> hari
                    </p>
                    <p class="mb-3">
                        <strong>Total harga:</strong> <span id="total_price_text">Rp 0</span>
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi Penyewaan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/user/rent-modal.blade.php ENDPATH**/ ?>