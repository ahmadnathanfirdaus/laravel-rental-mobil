<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <h4>Welcome, <?php echo e(auth()->user()->name); ?>!</h4>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
    </div>
    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <ul id="myTab" class="nav nav-tabs">
        <li class="nav-item">
            <a href="#cars" class="nav-link active" data-bs-toggle="tab">Data Mobil</a>
        </li>
        <li class="nav-item">
            <a href="#rents" class="nav-link" data-bs-toggle="tab">Data Penyewaan</a>
        </li>
        <li class="nav-item">
            <a href="#users" class="nav-link" data-bs-toggle="tab">Data User</a>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade show active" id="cars">
            <?php echo $__env->make('admin.data-cars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane fade" id="rents">
            <?php echo $__env->make('admin.data-rents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane fade" id="users">
            <?php echo $__env->make('admin.data-users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php echo $__env->make('admin.add-car-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.add-brand-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            $('a[data-bs-toggle="tab"]').on("shown.bs.tab", function(e) {
                var activeTab = $(e.target).text();
                var previousTab = $(e.relatedTarget).text();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/admin/index.blade.php ENDPATH**/ ?>