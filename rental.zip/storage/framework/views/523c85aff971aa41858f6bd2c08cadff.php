<?php if(count($rents) > 0): ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Mobil</th>
                <th>Tanggal Sewa</th>
                <th>Tanggal Pengembalian</th>
                <th>Total Harga</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($rent->car->brand->name . ' ' . $rent->car->name); ?></td>
                    <td><?php echo e($rent->rent_date); ?></td>
                    <td><?php echo e($rent->return_date); ?></td>
                    <td>Rp<?php echo e(number_format($rent->total_price, 2, ',', '.')); ?></td>
                    <td>
                        <?php if($rent->status == 'pending'): ?>
                            <span class="badge bg-warning"><?php echo e($rent->status); ?></span>
                        <?php elseif($rent->status == 'approved'): ?>
                            <span class="badge bg-success"><?php echo e($rent->status); ?></span>
                        <?php else: ?>
                            <span class="badge bg-danger"><?php echo e($rent->status); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p class="alert alert-danger">Tidak ada data</p>
<?php endif; ?>
<?php /**PATH /Users/ahmadnathanfirdaus/Projects/Website/rental-mobil/resources/views/user/data-rents.blade.php ENDPATH**/ ?>